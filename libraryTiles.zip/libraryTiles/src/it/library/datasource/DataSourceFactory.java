package it.library.datasource;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.postgresql.ds.PGPoolingDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import it.library.utils.DBType;
import oracle.jdbc.pool.OracleDataSource;

public class DataSourceFactory {

	private final static String DB_PROPERTIES = "db.properties";

	private static Logger logger = LoggerFactory.getLogger(DataSourceFactory.class.getSimpleName());

	/**
	 * Gets the data source.
	 *
	 * @param dbType the db type tipo di db per la connessione
	 * @return the data source datasource disponibile
	 * @throws SQLException 
	 */
	public DataSource getDataSource(String dbType) throws SQLException
	{

		logger.info("Start getDataSource");

		DataSource ds = null;

		try {

			/* Get Properties file */
			Properties prop = getDBProperties(DB_PROPERTIES);

			/* Get DB Type information */
			DBType dbInfo = DBType.valueOf(dbType);

			/* Check DB type  */
			switch (dbInfo) {
			case ORACLE:
				OracleDataSource oracle = new OracleDataSource();
				oracle.setURL(prop.getProperty(DBType.ORACLE.getUrl()));
				oracle.setUser( prop.getProperty( DBType.ORACLE.getUsername() )  );
				oracle.setPassword( prop.getProperty( DBType.ORACLE.getPassword() ) );
				logger.info("Get Oracle DB Properties");
				ds = oracle;
				break;

			case MYSQL:
				MysqlDataSource mySQL = new MysqlDataSource();
				mySQL.setURL(prop.getProperty(DBType.MYSQL.getUrl()));
				mySQL.setUser( prop.getProperty( DBType.MYSQL.getUsername() )  );
				mySQL.setPassword( prop.getProperty( DBType.MYSQL.getPassword() ) );
				ds = mySQL;
				logger.info("Get MysQL DB Properties");
				break;

			case MONGODB:
				break;

			case POSTGRESQL:
				PGPoolingDataSource postgreSQL = new PGPoolingDataSource();
				postgreSQL.setServerName(prop.getProperty(DBType.POSTGRESQL.getUrl()));
				postgreSQL.setUser( prop.getProperty( DBType.POSTGRESQL.getUsername() )  );
				postgreSQL.setPassword( prop.getProperty( DBType.POSTGRESQL.getPassword() ) );
				ds = postgreSQL;
				logger.info("Get MysQL DB Properties");
				break;

			case DB2:
				break;

			default:
				break;
			}


		} catch (IOException e) {
			logger.error("DB properties not found");
		}

		logger.info("End getDataSource");

		return ds;
	}


	/**
	 * Gets the DB properties.
	 * Recupera le informazione per la connessione al DataSource
	 *
	 * @param propertiesFile the properties file contiene il nome del file di properties per la connessione al DB
	 * @return the DB properties Properties contiene le properties per la configurazione della connessione al DataSource
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private Properties getDBProperties(String propertiesFile) throws IOException
	{

		/* Initialization of properties file */
		Properties properties = new Properties();

		/* Get InputStream from Property file */
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream(propertiesFile);
		
		/* Check Properties file  */
		if (inputStream != null && inputStream.available() > 0)
		{
			logger.info("Properties file {} found in classpath", propertiesFile);
			
			/* Set Properties file */
			properties.load(inputStream);
		}
		else
			logger.info("Properties file {} not found in classpath", propertiesFile);
		
		return properties;
	}


}
