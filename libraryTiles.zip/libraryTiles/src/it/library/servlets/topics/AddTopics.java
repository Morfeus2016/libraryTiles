package it.library.servlets.topics;

import it.library.servlet.login.Logout;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

@SuppressWarnings("serial")
public class AddTopics extends HttpServlet{
	
	/* Set logger */
	private Logger logger = Logger.getLogger(AddTopics.class.getName());
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		logger.info("Start Add Topics");
		
		/* Redirect to vies Add Topics */
		response.sendRedirect("view/topic/addTopic.jsp");
		
		logger.info("End Add Topics");
		
	}
	
	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
