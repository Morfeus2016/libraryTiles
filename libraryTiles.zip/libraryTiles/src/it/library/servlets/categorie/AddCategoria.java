package it.library.servlets.categorie;

import it.library.dao.impl.MySQLCategoryDAOImpl;
import it.library.pojos.categories.Categories;

import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;








import org.apache.log4j.Logger;

@SuppressWarnings("serial")
public class AddCategoria extends HttpServlet{

	/* Set logger */
	private Logger logger = Logger.getLogger(AddCategoria.class.getName());

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		logger.info("Start Add Categoria");

		/* Redirect to vies Add Topics */
		response.sendRedirect("view/category/addCategoria.jsp");

		logger.info("End Add Categoria");

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		logger.info("Start Add Categoria");

		/* Recupero elementi dal form */
		String titoloCategoria = request.getParameter("titolo");
		String descrCategoria  = request.getParameter("descrizione");
		
		/* DAO Initialization */
		MySQLCategoryDAOImpl categoriesDAO = null;
		
		/* Check New Category Insert */
		if (!titoloCategoria.isEmpty() && !descrCategoria.isEmpty())
		{
			/* Persist new Category*/
			Categories addCategory = new Categories();
			
			/* Set form values */
			addCategory.setTitolo(titoloCategoria);
			addCategory.setDescrizione(descrCategoria);
			addCategory.setTopics(0);
			addCategory.setEnable(true);
			addCategory.setDataCreazione( new Date(System.currentTimeMillis()) );
			addCategory.setDataModifica( new Date(System.currentTimeMillis())  );
			
			/* Call CategoriesDAO */
			categoriesDAO = new MySQLCategoryDAOImpl();
			
			/* Inser new category */
			categoriesDAO.addCategory(addCategory);
		}
		
		/* Recupero della lista delle */
		List<Categories> categorie = new ArrayList<Categories>();
		
		/* Recupero l'elenco delle categorie presenti */
		categorie = categoriesDAO.findAll();
		
		request.getSession().setAttribute("categorie", categorie);
		response.sendRedirect("view/category/addCategoria.jsp");
	
		logger.info("End Add Categoria");

	}

}
