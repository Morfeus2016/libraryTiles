package it.library.utils;

public enum DBProperties {
	
	DB_DRIVER_CLASS,
	DB_URL,
	DB_USERNAME,
	DB_PASSWORD,
	
}
