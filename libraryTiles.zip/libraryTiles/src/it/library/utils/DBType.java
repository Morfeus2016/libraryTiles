package it.library.utils;

public enum DBType {
	ORACLE("ORACLE_DB_DRIVER_CLASS","ORACLE_DB_URL","ORACLE_DB_USERNAME", "ORACLE_DB_PASSWORD"),
	MYSQL("MYSQL_DB_DRIVER_CLASS","MYSQL_DB_URL","MYSQL_DB_USERNAME","MYSQL_DB_PASSWORD"),
	POSTGRESQL("POSTGRESQL_DB_DRIVER_CLASS","POSTGRESQL_DB_URL","POSTGRESQL_DB_PASSWORD","POSTGRESQL_DB_PASSWORD"),
	MONGODB("MONGODB_DB_DRIVER_CLASS","MONGO_DB_URL","MONGO_DB_USERNAME","MONGO_DB_PASSWORD"),
	DB2("DB2_DB_DRIVER_CLASS","DB2_DB_URL","DB2_DB_USERNAME","DB2_DB_PASSWORD");
	
	private String driverClass;
	public String getDriverClass() {
		return driverClass;
	}

	public void setDriverClass(String driverClass) {
		this.driverClass = driverClass;
	}

	private String url;
	private String username;
	private String password;
	
	private DBType(String driverClass,String url, String username, String password)
	{
		this.driverClass = driverClass;
		this.url = url;
		this.username = username;
		this.password = password;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	
}
