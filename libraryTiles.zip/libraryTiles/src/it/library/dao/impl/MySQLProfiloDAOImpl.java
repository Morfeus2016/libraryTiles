package it.library.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

import it.library.connection.ConnectionFactory;
import it.library.dao.ProfiloDAO;
import it.library.pojo.profilo.Profilo;
import it.library.pojo.user.User;
import it.library.utils.DBType;

public class MySQLProfiloDAOImpl implements ProfiloDAO{
	
	/* Set Logger*/
	private Logger logger = Logger.getLogger(MySQLUserDAOImpl.class.getName());

	/* Set Connection */
	private Connection conn;
	
	/* SQL Query */
	private final static String profilo = "select * from profilo where id = ? and enable = 1";

	@Override
	public Profilo getProfiloById(Integer id) {
		
		logger.info("Start getProfiloById");

		/* Initialization return object */
		Profilo profilo =  new Profilo();

		/* Call PreparedStatement */
		ResultSet rs = null;
		PreparedStatement pds = null;
		try {

			/* Create Connection */
			conn = createConnection();

			/* Set Statement  */
			pds = conn.prepareStatement(MySQLProfiloDAOImpl.profilo);
			pds.setInt(1, id);


			/* Execute Query */
			rs = pds.executeQuery();

			/* Get ResultSet value */
			while (rs.next()) {

				/* Set Login Id */
				profilo.setId( rs.getInt("ID") );
				profilo.setProfilo( rs.getString("PROFILO") );
				profilo.setEnable(rs.getBoolean("ENABLE"));
				profilo.setDataCreazione( rs.getDate("DATA_CREAZIONE") );
				profilo.setDataModifica(rs.getDate("DATA_MODIFICA"));

			}

			/* Check login user */
			if (profilo.getId() != null)
				logger.info("Found Profilo related to Login User with Id " + id);

		} catch (Exception e) {
			logger.error(e.getMessage(), e.getCause());
		}finally {
			closeConnection(conn);
		}

		logger.info("End getProfiloById");

		return profilo;
	}
	
	public static Connection createConnection() throws Exception
	{

		/* Call Connection Factory */
		ConnectionFactory connFactory = new ConnectionFactory();

		/* Return Connection */
		return connFactory.getConnection(DBType.MYSQL.toString());
	}

	public static void closeConnection(Connection conn)
	{
		try {
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
