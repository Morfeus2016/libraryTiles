package it.library.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import it.library.connection.ConnectionFactory;
import it.library.dao.CategoriesDAO;
import it.library.pojos.categories.Categories;
import it.library.utils.DBType;

public class MySQLCategoryDAOImpl implements CategoriesDAO{

	/* Set Logger*/
	private Logger logger = Logger.getLogger(MySQLCategoryDAOImpl.class.getName());

	/* Set Connection */
	private Connection conn;
	
	/* Categories query */
	private final static String add = "INSERT INTO CATEGORIE (TITOLO, DESCRIZIONE, TOPICS, ENABLE, DATA_CREAZIONE, DATA_MODIFICA) VALUES ( ?, ?, ?, ?, ?, ?)";
	private final static String FINDALL = "SELECT * FROM CATEGORIE ORDER BY ASC";
	@Override
	public void addCategory(Categories category) {
		
		logger.info("Start Add Category");
		
		/* Set PreparedStatement */
		PreparedStatement pds = null;
		
		try {
			
			/* Get Connection */
			conn = createConnection();
			
			/* Initialization PreparedStatement */
			pds = conn.prepareStatement(MySQLCategoryDAOImpl.add);
			
			/* Set parameter */
			pds.setString(1, category.getTitolo());
			pds.setString(2, category.getDescrizione());
			pds.setInt(3, 0);
			pds.setBoolean(4, Boolean.TRUE);
			pds.setDate(5, new Date(System.currentTimeMillis()) );
			pds.setDate(6, new Date(System.currentTimeMillis()) );

			
			boolean result = pds.execute();
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		
		logger.info("End Add Category");
		
	}

	@Override
	public void updateCategory(Categories category) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCategory(Categories category) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Categories> findAll() {
		
		logger.info("Start Find All");
		
		/* Set PreparedStatement */
		PreparedStatement pds = null;
		
		/* Initialization List Categorie */
		List<Categories> allCategorie = new ArrayList<Categories>();
		
		try {
			
			/* Get Connection */
			conn = createConnection();
			
			/* Initialization PreparedStatement */
			pds = conn.prepareStatement(MySQLCategoryDAOImpl.FINDALL);
			
			/* Get ResultSet */
			ResultSet result = pds.executeQuery();
			
			/* Create lists of Categorie */
			while (result.next()) {
				
				/* Get new object */
				Categories categoria = new Categories();
				
				/*Set Values*/
				categoria.setTitolo(result.getString("TITOLO"));
				categoria.setDescrizione(result.getString("DESCRIZIONE"));
				
				allCategorie.add(categoria);
				
			}
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		
		logger.info("End Add Category");
		
		return allCategorie;
	}

	@Override
	public Categories findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Categories findByTitle(String title) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static Connection createConnection() throws Exception
	{

		/* Call Connection Factory */
		ConnectionFactory connFactory = new ConnectionFactory();

		/* Return Connection */
		return connFactory.getConnection(DBType.MYSQL.toString());
	}

	public static void closeConnection(Connection conn)
	{
		try {
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
