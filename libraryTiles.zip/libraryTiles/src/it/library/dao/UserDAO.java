package it.library.dao;

import it.library.pojo.user.User;

public interface UserDAO  {
	public User getUserById(Integer id);
}
