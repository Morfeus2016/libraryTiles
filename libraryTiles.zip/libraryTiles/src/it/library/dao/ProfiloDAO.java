package it.library.dao;

import it.library.pojo.profilo.Profilo;

public interface ProfiloDAO {
	
	public Profilo getProfiloById(Integer id);
}
