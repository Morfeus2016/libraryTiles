package it.library.dao;

import java.util.List;

import it.library.pojos.categories.Categories;

public interface CategoriesDAO {

	/*Add New CAtegory*/
	public void addCategory(Categories category);
	
	/* Update Category*/
	public void updateCategory(Categories category);
	
	/*Delete Category*/
	public void deleteCategory(Categories category);
	
	/*Find All Categories*/
	public List<Categories> findAll();
	
	/* Find Categoy By Id */
	public Categories findById(Integer id);
	
	/*Find Category By Title*/
	public Categories findByTitle(String title);
}
