package it.library.dao;

import it.library.pojo.login.LoginUser;

public interface LoginDAO {
	
	public LoginUser getLoginUser(String username, String password);

}
