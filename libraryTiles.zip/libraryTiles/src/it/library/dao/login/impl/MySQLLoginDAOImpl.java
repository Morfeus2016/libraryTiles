package it.library.dao.login.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;

import com.mysql.jdbc.Statement;

import it.library.connection.ConnectionFactory;
import it.library.dao.LoginDAO;
import it.library.pojo.login.LoginUser;
import it.library.utils.DBType;

/**
 * 
 * @author alfredo
 *
 */
public class MySQLLoginDAOImpl implements LoginDAO {
	
	/* Set Logger*/
	private Logger logger = Logger.getLogger(MySQLLoginDAOImpl.class.getName());
	
	/* Set Connection */
	private Connection conn;
	
	private final static String loginUser = "select * from LOGIN where username = ? and password = ? and enable = 1 ";
	
	/**
	 * 
	 */
	@Override
	public LoginUser getLoginUser(String username, String password) {
		
		logger.info("Start getLoginUser");
		
		/* Initialization return object */
		LoginUser loginUser =  new LoginUser();
		
		/* Call PreparedStatement */
		ResultSet rs = null;
		PreparedStatement pds = null;
		try {
			
			/* Create Connection */
			conn = createConnection();
			
			/* Set Statement  */
			pds = conn.prepareStatement(MySQLLoginDAOImpl.loginUser);
			pds.setString(1, username);
			pds.setString(2, password);
            
			/* Execute Query */
			rs = pds.executeQuery();
			
			/* Get ResultSet value */
			while (rs.next()) {
				
				/* Set Login Id */
				loginUser.setId(rs.getInt("ID"));
				loginUser.setUsername(rs.getString("USERNAME"));
				loginUser.setPasssword(rs.getString("PASSWORD") );
				loginUser.setEnable(rs.getBoolean("ENABLE"));
				loginUser.setIdUser(rs.getInt("ID_USER"));
				loginUser.setDataCeazione(rs.getDate("DATA_CREAZIONE"));
				loginUser.setDataModifica(rs.getDate("DATA_MODIFICA"));

			}
			
			/* Check login user */
			if (loginUser.getIdUser() != null)
				logger.info("Found User related to Login User with Username " + username);
			
		} catch (Exception e) {
			logger.error(e.getMessage(), e.getCause());
		}finally {
			closeConnection(conn);
		}
		
		logger.info("End getLoginUser");
		
		return loginUser;
	}
	
	public static Connection createConnection() throws Exception
	{
		
		/* Call Connection Factory */
		ConnectionFactory connFactory = new ConnectionFactory();
		
		/* Return Connection */
		return connFactory.getConnection(DBType.MYSQL.toString());
	}
	
	public static void closeConnection(Connection conn)
	{
		try {
			conn.close();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

}
