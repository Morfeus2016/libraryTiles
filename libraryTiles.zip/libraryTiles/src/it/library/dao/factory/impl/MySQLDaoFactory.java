package it.library.dao.factory.impl;

import it.library.dao.LoginDAO;
import it.library.dao.factory.DaoFactory;
import it.library.dao.login.impl.MySQLLoginDAOImpl;


public class MySQLDaoFactory extends DaoFactory{

	@Override
	public LoginDAO getLoginDAO() {
		return new MySQLLoginDAOImpl();
	}

	

}
