package it.library.dao.factory;

import it.library.dao.LoginDAO;
import it.library.dao.factory.impl.MySQLDaoFactory;
import it.library.utils.DBType;

/**
 * Classe astratta per la definizione di tutti i DAO della
 * web application
 * @author alfredo
 *
 */
public abstract class DaoFactory {
	
	public static DaoFactory getDAOFactory(DBType whichFactory)
	{
		switch (whichFactory) {
		case MYSQL:
			return new MySQLDaoFactory();
			

		default:
			break;
		}
		return null;
	}
	
	public abstract LoginDAO getLoginDAO();
	
}
