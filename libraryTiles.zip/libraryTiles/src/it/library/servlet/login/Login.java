package it.library.servlet.login;

import it.library.dao.impl.MySQLProfiloDAOImpl;
import it.library.dao.impl.MySQLUserDAOImpl;
import it.library.dao.login.impl.MySQLLoginDAOImpl;
import it.library.pojo.login.AuthenticatedUser;
import it.library.pojo.login.LoginUser;
import it.library.pojo.profilo.Profilo;
import it.library.pojo.user.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import sun.util.logging.resources.logging;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/* Set logger */
	private Logger logger = Logger.getLogger(Login.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		logger.info("Call login Servlet");				response.sendRedirect("view/login/login.jsp");
		
		logger.info("End login Servlet");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		logger.info("Call Login Post method");
		
		/* Set redirect page */
		String nextPage = new String("view/login/login.jsp");
		
		/* check Login Informations */
		String username = request.getParameter("username"); 
		String password = request.getParameter("password");
		
		/* Check Login User */
		boolean checkUser = (username != null && !username.isEmpty()) ? true : false;
		boolean checkPwd = (password != null && !password.isEmpty()) ? true : false;
		
		/* Get User by login credential */
		MySQLLoginDAOImpl loginUserDAO =null;
		
		/* Se Login User */
		LoginUser  userLogin = null;
		
		/* Inserisco le infomrazioni relative all'utente autenticato in sessione */
		AuthenticatedUser authUser = new AuthenticatedUser();
		
		/* check credenziali utente loggato */
		if (checkUser && checkPwd)
		{
			loginUserDAO = new MySQLLoginDAOImpl();
			
			/* Get User related to Login User */
			userLogin = loginUserDAO.getLoginUser(username, password);
			
			/* Set login User */
			User user = null;
			/* Check profilo login user */
			String profilo = null;
			
			/* Check login user */
			if (userLogin.getIdUser() != null ){
				
				/* User initialization */
				user = new User();
				
				/* Call userDAO */
				MySQLUserDAOImpl userDAO = new MySQLUserDAOImpl();
				
				user = userDAO.getUserById(userLogin.getIdUser());
				
				/* Check User Profile */
				if (user != null && user.getIdProfilo() > 0)
				{
					/* Recupero il profilo utenete in sessione */
					MySQLProfiloDAOImpl loginProfilo = new MySQLProfiloDAOImpl();
					
					/* Recupero profilo utente by id */
					Profilo userProfilo = loginProfilo.getProfiloById(user.getIdProfilo());
				
					/* Check user profile */
					if (userProfilo != null )
					{
						profilo = userProfilo.getProfilo();
					}
					else
						logger.error("Profilo per l'utente con id " + user.getId() + " inesistente");
				}
				else
					logger.info("Not Found User related to Login User with username " + username);
			}
			else
				logger.info("Not Found User related to Login User with username " + username);
			
			
			/* Set informazioni utente autenticato */
			authUser.setNome(user.getNome());
			authUser.setCognome(user.getCognome());
			authUser.setProfilo(profilo);
				
			/* Check Valdation of Login User */
			nextPage = "view/home/home.jsp";
		}
		else {
			
			logger.info("Login credential wrong");
			
			/* Login errato */
			doGet(request, response);
		}
		
		/* Inserisco l'utente loggato in sessione */
		HttpSession session = request.getSession(true);
		
		/* Inserisco in sessione utente autenticato */
		session.setAttribute("authUser", authUser);
		
		
		response.sendRedirect(nextPage);
	}

}
