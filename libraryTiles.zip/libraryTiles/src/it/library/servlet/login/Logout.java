package it.library.servlet.login;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class Logout
 */
@WebServlet("/logout")
public class Logout extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	/* Set logger */
	private Logger logger = Logger.getLogger(Logout.class.getName());
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Logout() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		logger.info("Start doGet Logout Servlet");
		
		/* Verifica presenza valori in sessione */
		HttpSession session = request.getSession();
		
		/* Get Attribute from current Sesison */
		Enumeration sessionattributes = session.getAttributeNames();
		
		while (sessionattributes.hasMoreElements()) {
			/**/
			Object object = (Object) sessionattributes.nextElement();
			logger.info("Attribute in Sesison : " + object.toString());
			
			/* Check Authentication User Information in Session or Cookies */
			if  (object.toString().equals("authUser"))
			{
				/* Remove from session Authenticate User Information  */
				session.removeAttribute("authUser");
				
				/*  */
			}
		}
		
		/* Recupero gli oggetti presenti in sessione */
		
		logger.info("End doGet Logout Servlet");
		
		response.sendRedirect("/libraryTiles/");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.info("Start doPost Logout Servlet");
		logger.info("End doPost Logout Servlet");
	}

}
