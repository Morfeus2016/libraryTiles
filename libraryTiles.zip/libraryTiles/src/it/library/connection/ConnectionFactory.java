package it.library.connection;

import java.sql.Connection;

import javax.sql.DataSource;

import it.library.datasource.DataSourceFactory;

public class ConnectionFactory {

	private DataSourceFactory dataSF;

	/**
	 * 
	 */
	private void ConnectionFactory()
	{
		dataSF = new DataSourceFactory();
	}

	/**
	 * 
	 * @param dbName
	 * @throws Exception 
	 */
	private Connection createConnection(String dbName) throws Exception
	{
		/* Set reurn object */
		Connection conn= null;
		
		/* Set DataSource */
		ConnectionFactory();
		
		if (dataSF != null)
		{
			/* Set Data Source */
			DataSource ds = dataSF.getDataSource(dbName);
			
			/* Set connection to DataSource  */
			conn = ds.getConnection();
		}
		else
			System.err.println("Data Source error");
		
		
		return conn;
	}
	
	/**
	 * Create connection to DataSource.
	 * @param dbName String indica il data source per la connessione
	 * @return Connection conn Connessione al Data Source indicato
	 * @throws Exception
	 */
	public Connection getConnection(String dbName) throws Exception
	{
		return createConnection(dbName);
	}

}
